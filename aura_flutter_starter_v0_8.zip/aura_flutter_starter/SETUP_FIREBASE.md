# AURA Firebase Authentication setup

The Flutter source now contains Firebase email/password and Google sign-in flows. They are **not live until you complete these steps**.

## 1. Create the Firebase project
1. Open https://console.firebase.google.com/ and create a project for AURA.
2. Add an Android app. Use the application ID/package name from your Android project (after `flutter create .`, check `android/app/build.gradle` or `android/app/build.gradle.kts`).
3. Download `google-services.json` and put it at `android/app/google-services.json`. Do not upload it to public repositories.
4. Follow the current Firebase Flutter setup instructions to add the Google Services Gradle plugin to the Android Gradle configuration.

## 2. Add FlutterFire configuration
Install FlutterFire CLI and run `flutterfire configure` from the project folder. This generates `lib/firebase_options.dart`. If you choose to use generated options, update `main()` to call `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)` and import that generated file. The current starter uses native Android Firebase configuration with `Firebase.initializeApp()`.

## 3. Enable providers
In Firebase Console → Authentication → Sign-in method, enable **Email/Password** and **Google**. For Google, ensure SHA-1 and SHA-256 signing certificate fingerprints are added in Firebase project settings; use the debug fingerprints for local testing and production fingerprints for release. Re-download `google-services.json` after changing Android app configuration if Firebase instructs you to.

## 4. Install dependencies and test
Run `flutter pub get`, then `flutter run` on an emulator or Android device. Test sign-up, sign-out/sign-in, invalid credentials, and Google cancellation. Do not use real user accounts until you have tested the flow.

## Important security notes
- This starter does not include a user database, profiles, rotating public Aura IDs, private chat, or streak synchronization.
- Never store plaintext passwords yourself. Firebase Authentication handles credential management.
- Before launch, add account deletion, privacy policy, age-appropriate safety controls, abuse reporting, and secure database rules.
- Flutter/Dart was not installed in the authoring environment, so this project has not been compiled or runtime-tested here.
