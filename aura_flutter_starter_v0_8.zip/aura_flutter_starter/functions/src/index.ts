import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { logger } from "firebase-functions";
import { randomBytes } from "node:crypto";

initializeApp();
const db = getFirestore();
const DAY_MS = 24 * 60 * 60 * 1000;

function makeAlias(): string {
  // Random public alias; never use it as an authentication credential.
  const value = randomBytes(4).readUInt32BE(0).toString(36).toUpperCase().padStart(7, "0").slice(-7);
  return `AU-${value.slice(0, 3)}-${value.slice(3)}`;
}

/** Runs hourly. A user's alias changes once its server-stored 24-hour expiry is reached. */
export const rotateExpiredAuraIds = onSchedule("every 60 minutes", async () => {
  const now = Timestamp.now();
  const expired = await db.collection("users").where("auraIdExpiresAt", "<=", now).limit(200).get();
  for (const userDoc of expired.docs) {
    await db.runTransaction(async (tx) => {
      const fresh = await tx.get(userDoc.ref);
      if (!fresh.exists) return;
      const data = fresh.data()!;
      const expiresAt = data.auraIdExpiresAt as Timestamp | undefined;
      if (!expiresAt || expiresAt.toMillis() > Date.now()) return;

      const oldAlias = data.publicAuraId as string | undefined;
      let newAlias = "";
      // Collision handling: try a few random aliases, checking inside transaction.
      for (let attempt = 0; attempt < 8; attempt++) {
        const candidate = makeAlias();
        const candidateRef = db.collection("publicAuraIds").doc(candidate);
        const candidateDoc = await tx.get(candidateRef);
        if (!candidateDoc.exists) { newAlias = candidate; break; }
      }
      if (!newAlias) { logger.error("Unable to allocate unique Aura ID", { uid: userDoc.id }); return; }

      if (oldAlias) tx.delete(db.collection("publicAuraIds").doc(oldAlias));
      tx.set(db.collection("publicAuraIds").doc(newAlias), { uid: userDoc.id, createdAt: FieldValue.serverTimestamp() });
      tx.update(userDoc.ref, {
        publicAuraId: newAlias,
        auraIdCreatedAt: FieldValue.serverTimestamp(),
        auraIdExpiresAt: Timestamp.fromMillis(Date.now() + DAY_MS),
      });
    });
  }
});

/**
 * AURA Bond Streak engine (starter).
 * A streak counts only when both members send an `aura` message on the same UTC day.
 */
import { onDocumentCreated } from "firebase-functions/v2/firestore";

export const updateBondStreakOnAuraExchange = onDocumentCreated(
  "conversations/{conversationId}/messages/{messageId}",
  async (event) => {
    const message = event.data?.data();
    if (!message || message.type !== "aura" || typeof message.senderId !== "string") return;

    const conversationRef = db.collection("conversations").doc(event.params.conversationId);
    const conversationSnap = await conversationRef.get();
    if (!conversationSnap.exists) return;
    const conversation = conversationSnap.data()!;
    if (conversation.status !== "accepted" || !Array.isArray(conversation.members) ||
        conversation.members.length !== 2 || !conversation.members.includes(message.senderId)) return;

    const createdAt = message.createdAt as Timestamp | undefined;
    if (!createdAt) return;
    const otherUid = conversation.members.find((uid: string) => uid !== message.senderId);
    if (!otherUid) return;

    const dayKey = new Date(createdAt.toMillis()).toISOString().slice(0, 10);
    const dayStart = Timestamp.fromDate(new Date(`${dayKey}T00:00:00.000Z`));
    const dayEnd = Timestamp.fromDate(new Date(`${dayKey}T23:59:59.999Z`));
    const otherAura = await conversationRef.collection("messages")
      .where("senderId", "==", otherUid)
      .where("type", "==", "aura")
      .where("createdAt", ">=", dayStart)
      .where("createdAt", "<=", dayEnd)
      .limit(1).get();
    if (otherAura.empty) return;

    await db.runTransaction(async (tx) => {
      const fresh = await tx.get(conversationRef);
      if (!fresh.exists) return;
      const data = fresh.data()!;
      if (data.status !== "accepted" || data.lastBondDay === dayKey) return;
      const lastDay = typeof data.lastBondDay === "string" ? data.lastBondDay : "";
      const previous = lastDay ? new Date(`${lastDay}T00:00:00.000Z`) : null;
      const current = new Date(`${dayKey}T00:00:00.000Z`);
      const consecutive = previous !== null && current.getTime() - previous.getTime() === DAY_MS;
      const count = typeof data.bondStreakCount === "number" ? data.bondStreakCount : 0;
      tx.update(conversationRef, {
        bondStreakCount: consecutive ? count + 1 : 1,
        lastBondDay: dayKey,
        lastBondExchangeAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
    });
  }
);
