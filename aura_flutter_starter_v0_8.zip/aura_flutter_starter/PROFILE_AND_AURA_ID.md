# AURA Profile & Public ID — milestone 0.3

## Included in this source milestone
- A profile screen with editable display name and bio (in-memory preview only).
- A public Aura ID preview that changes with the UTC day.
- A sign-out button when Firebase Authentication has a current user.
- Explicit UI labels explaining that the ID and profile are not production-backed.

## Important limitations
- Profile edits are not saved to a database and reset when the app process is restarted.
- The displayed ID is derived locally for demonstration. It is not a secure identifier, is not guaranteed unique, and is not synchronized between devices.
- This sample changes its preview at the next UTC day boundary; it does not implement a secure rolling 24-hour rotation from account creation.
- Do not use the displayed public ID as an authentication credential or authorization check.

## Production design
1. Keep Firebase Authentication UID as the permanent private account key.
2. Store profile fields in Firestore under a user-owned document, protected by Firestore Security Rules.
3. Generate a random public alias on a trusted backend and store its `createdAt` / `expiresAt` timestamps.
4. Rotate aliases server-side after the chosen 24-hour window, using a scheduled function or an authenticated callable function and a transaction.
5. Avoid exposing the permanent UID in public profile URLs. Decide how friend links and abuse reports remain valid across alias changes.
6. Add automated tests for rotation timing, collision handling, access control, and account deletion.

This milestone is UI/source scaffolding only. Configure Firebase and run on a real Android device before treating it as functional authentication/profile storage.
