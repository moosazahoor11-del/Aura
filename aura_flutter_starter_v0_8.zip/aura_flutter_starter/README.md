# AURA — Connected Soul (Flutter starter)

Android-first Flutter source for the AURA black-and-violet social concept.

## Included
- Cinematic welcome and sign-in UI.
- Firebase email/password and Google authentication integration code.
- Feed, Discover, Bonds, and My Aura navigation.
- Editable profile preview, local public Aura ID preview, and conditional sign-out.
- Clear in-app notices where backend functionality is not connected.

## Run
1. Install Flutter and Android Studio.
2. From this folder run `flutter pub get`.
3. Follow `SETUP_FIREBASE.md` to configure Firebase Android and OAuth.
4. Run `flutter run` on an emulator or Android device.

## Status
This is starter source code, not a compiled APK. It has not been compiled or device-tested in this environment. Profile editing is local/in-memory; the rotating public ID is a demo preview that changes with the UTC day. Neither is production persistence/security. See `PROFILE_AND_AURA_ID.md` for the production architecture.

## New: Firestore + rotating Aura ID backend scaffold
See `FIRESTORE_PROFILE_AND_ROTATION.md`. The Firestore rules and scheduled Cloud Function are starter code only; deploy and test them in your own Firebase project. The Flutter profile screen is not yet wired to Firestore.

## Mood Inbox / chat UI

The Inbox tab and chat composer are currently local demonstrations. See `CHAT_AND_SAFETY.md` for the proposed data model and security checklist. Firestore chat access is intentionally not enabled yet.

## v0.7 chat scaffold
See `REALTIME_CHAT_V0_7.md` and `lib/services/aura_chat_service.dart` for the Firestore-backed chat service scaffold and security-rule notes. The UI remains demo-only until explicitly wired to the service, and rules require emulator testing before production.

## v0.8 Bond Streak Engine
See `BOND_STREAK_ENGINE_V0_8.md` and the `updateBondStreakOnAuraExchange` Cloud Function. It counts mutual `type: "aura"` messages per UTC day. The UI is not yet connected to send Aura messages, and this starter has not been compiled/deployed/security-tested.
