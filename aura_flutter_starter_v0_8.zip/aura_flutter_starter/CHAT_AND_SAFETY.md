# AURA Mood Inbox and Chat — v0.6 foundation

## Included now

- Five-tab shell: Feed, Discover, Bonds, Inbox, My Aura.
- Mood Inbox with illustrative conversations.
- Chat screen with local message bubbles and composer interaction.
- Violet/black AURA styling and clear demo-mode labels.

## Important status

This is a UI prototype only. Messages are held in memory and disappear when the screen/app is closed. No message is sent to another person, no Firestore listener is connected, and there is no live chat backend yet. The existing Firestore rules deny access to chat collections by default; keep that protection until reviewed rules are deployed.

## Suggested production data model

```text
conversations/{conversationId}
  participantUids: [uidA, uidB]
  createdAt: server timestamp
  lastMessageAt: server timestamp
  status: "active" | "blocked" | "closed"

conversations/{conversationId}/messages/{messageId}
  senderUid: authenticated UID
  text: string (limited length)
  createdAt: server timestamp
  type: "text"
```

## Before connecting Firestore

1. Create conversations through a trusted backend or a carefully constrained transaction; do not allow a client to add arbitrary participants.
2. Rules must check that the signed-in user is a participant in the parent conversation.
3. Messages must require `senderUid == request.auth.uid`, restrict fields and text length, and use server timestamps.
4. Add conversation requests/consent, block and report flows, rate limits, abuse handling, and deletion/retention policy.
5. Do not store passwords or unnecessary personal information in message documents.
6. Test rules in the Firebase Emulator Suite with allowed and denied cases before deployment.

## Next engineering step

Implement a `ChatRepository` using `cloud_firestore` streams and writes, then add rules and emulator tests together. Only after that should the UI be labelled live chat.
