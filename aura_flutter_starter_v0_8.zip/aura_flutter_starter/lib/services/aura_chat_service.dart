import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Firestore-backed messaging service scaffold for AURA.
/// Requires the matching firestore.rules to be deployed and Firebase configured.
/// This service is not yet wired into the demo Inbox UI.
class AuraChatService {
  AuraChatService({FirebaseFirestore? firestore, FirebaseAuth? auth})
      : _db = firestore ?? FirebaseFirestore.instance,
        _auth = auth ?? FirebaseAuth.instance;

  final FirebaseFirestore _db;
  final FirebaseAuth _auth;

  String get _uid {
    final uid = _auth.currentUser?.uid;
    if (uid == null) throw StateError('Sign in before using AURA chat.');
    return uid;
  }

  /// Starts a consent-based conversation request. The other person must accept.
  Future<String> requestConversation(String recipientUid) async {
    final sender = _uid;
    if (recipientUid.trim().isEmpty || recipientUid == sender) {
      throw ArgumentError('Choose another valid AURA account.');
    }
    // Block checks must be performed by the trusted backend before production launch.
    final ref = _db.collection('conversations').doc();
    await ref.set({
      'members': [sender, recipientUid],
      'initiatedBy': sender,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> acceptConversation(String conversationId) async {
    await _db.collection('conversations').doc(conversationId).update({
      'status': 'accepted',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> declineConversation(String conversationId) async {
    await _db.collection('conversations').doc(conversationId).update({
      'status': 'declined',
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchMyConversations() {
    return _db.collection('conversations')
        .where('members', arrayContains: _uid)
        .orderBy('updatedAt', descending: true)
        .snapshots();
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchMessages(String conversationId) {
    return _db.collection('conversations').doc(conversationId)
        .collection('messages').orderBy('createdAt').snapshots();
  }

  Future<void> sendText(String conversationId, String rawText) async {
    final text = rawText.trim();
    if (text.isEmpty || text.length > 2000) {
      throw ArgumentError('Message must contain 1–2000 characters.');
    }
    final conversation = _db.collection('conversations').doc(conversationId);
    await _db.runTransaction((tx) async {
      final snapshot = await tx.get(conversation);
      final data = snapshot.data();
      if (!snapshot.exists || data == null || data['status'] != 'accepted' ||
          !(data['members'] as List<dynamic>).contains(_uid)) {
        throw StateError('This conversation is not available.');
      }
      final message = conversation.collection('messages').doc();
      tx.set(message, {
        'senderId': _uid,
        'text': text,
        'createdAt': FieldValue.serverTimestamp(),
        'type': 'text',
      });
      tx.update(conversation, {'updatedAt': FieldValue.serverTimestamp()});
    });
  }

  Future<void> blockUser(String targetUid) async {
    if (targetUid == _uid || targetUid.trim().isEmpty) {
      throw ArgumentError('Invalid account to block.');
    }
    await _db.collection('users').doc(_uid).collection('blockedUsers')
        .doc(targetUid).set({'createdAt': FieldValue.serverTimestamp()});
  }

  Future<void> reportUser({required String targetUid, required String reason}) async {
    final safeReason = reason.trim();
    if (targetUid == _uid || safeReason.isEmpty || safeReason.length > 500) {
      throw ArgumentError('Please provide a valid report reason.');
    }
    await _db.collection('reports').add({
      'reporterUid': _uid,
      'targetUid': targetUid,
      'reason': safeReason,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'open',
    });
  }
}
