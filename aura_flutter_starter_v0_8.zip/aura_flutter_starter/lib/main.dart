import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
    AuraAuth.firebaseReady = true;
  } catch (_) {
    // Keep the UI usable until the developer adds Firebase Android configuration.
    AuraAuth.firebaseReady = false;
  }
  runApp(const AuraApp());
}

class AuraAuth {
  static bool firebaseReady = false;
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static Future<UserCredential> emailSignIn(String email, String password) =>
      _auth.signInWithEmailAndPassword(email: email.trim(), password: password);

  static Future<UserCredential> emailSignUp(String email, String password) =>
      _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);

  static Future<UserCredential> googleSignIn() async {
    final account = await GoogleSignIn().signIn();
    if (account == null) throw FirebaseAuthException(code: 'cancelled', message: 'Google sign-in was cancelled.');
    final tokens = await account.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: tokens.accessToken,
      idToken: tokens.idToken,
    );
    return _auth.signInWithCredential(credential);
  }
}

const auraBg = Color(0xFF09060F);
const auraPanel = Color(0xFF171020);
const auraViolet = Color(0xFFB879FF);
const auraPink = Color(0xFFE5A6FF);

class AuraApp extends StatelessWidget {
  const AuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AURA — Connected Soul',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: auraBg,
        colorScheme: const ColorScheme.dark(
          primary: auraViolet,
          secondary: auraPink,
          surface: auraPanel,
        ),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: auraPanel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF7134A5), Color(0xFF241334)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(color: auraViolet.withValues(alpha: .22), blurRadius: 30),
                  ],
                ),
                child: const Center(
                  child: Text('✧', style: TextStyle(fontSize: 42, color: auraPink)),
                ),
              ),
              const SizedBox(height: 28),
              const Text('AURA', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w700, letterSpacing: 7)),
              const SizedBox(height: 8),
              const Text('Connected Soul', style: TextStyle(fontSize: 20, color: auraPink)),
              const SizedBox(height: 12),
              const Text('Don’t just share a moment. Share the feeling behind it.', style: TextStyle(color: Colors.white70, height: 1.5, fontSize: 15)),
              const SizedBox(height: 34),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SignInScreen())),
                  style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 17), backgroundColor: auraViolet, foregroundColor: auraBg),
                  child: const Text('Enter AURA', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 12),
              const Center(child: Text('A quiet space for every version of you.', style: TextStyle(color: Colors.white38, fontSize: 12))),
              const Spacer(),
              const Center(child: Text('EARLY ANDROID STARTER · BACKEND NOT CONNECTED', style: TextStyle(fontSize: 9, letterSpacing: 1.2, color: Colors.white30))),
            ],
          ),
        ),
      ),
    );
  }
}

class SignInScreen extends StatefulWidget {
  const SignInScreen({super.key});
  @override
  State<SignInScreen> createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool isSignUp = false;
  bool busy = false;

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> emailAction() async {
    if (email.text.trim().isEmpty || password.text.length < 6) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Enter an email and a password with at least 6 characters.'),
      ));
      return;
    }
    if (!AuraAuth.firebaseReady) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Firebase is not configured yet. Follow SETUP_FIREBASE.md.'),
      ));
      return;
    }
    setState(() => busy = true);
    try {
      if (isSignUp) {
        await AuraAuth.emailSignUp(email.text, password.text);
      } else {
        await AuraAuth.emailSignIn(email.text, password.text);
      }
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuraShell()));
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Authentication failed.')));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not sign in. Check your connection and Firebase setup.')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> googleAction() async {
    if (!AuraAuth.firebaseReady) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Google sign-in needs Firebase and Android OAuth setup. See SETUP_FIREBASE.md.'),
      ));
      return;
    }
    setState(() => busy = true);
    try {
      await AuraAuth.googleSignIn();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const AuraShell()));
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message ?? 'Google sign-in failed.')));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Google sign-in was not completed. Check OAuth setup.')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Your space, your pace'), backgroundColor: auraBg),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(24), children: [
      const Text('Welcome to AURA', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      const Text('Sign in to continue your story.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 28),
      TextField(controller: email, keyboardType: TextInputType.emailAddress, autofillHints: const [AutofillHints.email], decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.mail_outline))),
      const SizedBox(height: 14),
      TextField(controller: password, obscureText: true, autofillHints: const [AutofillHints.password], decoration: const InputDecoration(labelText: 'Password (6+ characters)', prefixIcon: Icon(Icons.lock_outline))),
      const SizedBox(height: 18),
      FilledButton(onPressed: busy ? null : emailAction, style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)), child: Text(busy ? 'Please wait…' : (isSignUp ? 'Create account' : 'Sign in'))),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: busy ? null : googleAction, icon: const Icon(Icons.g_mobiledata, size: 28), label: const Text('Continue with Google')),
      TextButton(onPressed: busy ? null : () => setState(() => isSignUp = !isSignUp), child: Text(isSignUp ? 'Already have an account? Sign in' : 'New to AURA? Create an account')),
      const SizedBox(height: 16),
      Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(14)), child: Text(AuraAuth.firebaseReady ? 'Firebase initialized. Enable Email/Password and Google providers in Firebase Console before testing.' : 'Firebase setup required. Authentication is not available until you add the Android Firebase configuration. See SETUP_FIREBASE.md.', style: const TextStyle(color: Colors.white60, fontSize: 12, height: 1.5))),
    ])),
  );
}

class AuraShell extends StatefulWidget {
  const AuraShell({super.key});
  @override
  State<AuraShell> createState() => _AuraShellState();
}

class _AuraShellState extends State<AuraShell> {
  int selected = 0;
  final pages = const [HomePage(), DiscoverPage(), BondsPage(), InboxPage(), ProfilePage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: pages[selected]),
    bottomNavigationBar: NavigationBar(
      selectedIndex: selected,
      onDestinationSelected: (value) => setState(() => selected = value),
      backgroundColor: const Color(0xFF100B18),
      indicatorColor: auraViolet.withValues(alpha: .18),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.auto_awesome_outlined), selectedIcon: Icon(Icons.auto_awesome), label: 'Feed'),
        NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Discover'),
        NavigationDestination(icon: Icon(Icons.all_inclusive), selectedIcon: Icon(Icons.all_inclusive), label: 'Bonds'),
        NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Inbox'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'My Aura'),
      ],
    ),
  );
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('AURA ✧', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, letterSpacing: 2)),
    const SizedBox(height: 5), const Text('What does today feel like?', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 22),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF35204C), Color(0xFF171020)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('✧  YOUR MOMENT', style: TextStyle(color: auraPink, letterSpacing: 1.5, fontSize: 11)), SizedBox(height: 12), Text('Some feelings don’t need a caption. They need a little space.', style: TextStyle(fontSize: 21, height: 1.35)), SizedBox(height: 16), Text('Sample content · Feed backend not connected', style: TextStyle(color: Colors.white38, fontSize: 11))]),),
    const SizedBox(height: 18), const Text('Mood worlds', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)), const SizedBox(height: 12),
    const Wrap(spacing: 8, runSpacing: 8, children: [MoodChip('☾ Midnight'), MoodChip('✧ Rainy'), MoodChip('✦ Sunset'), MoodChip('❋ Blooming')]),
    const SizedBox(height: 22), FilledButton.icon(onPressed: () => showDialog(context: context, builder: (_) => const AlertDialog(title: Text('Create a moment'), content: Text('Creation studio will be connected in the next build step.'))), icon: const Icon(Icons.add), label: const Text('Create a moment')),
  ]);
}

class MoodChip extends StatelessWidget {
  final String label;
  const MoodChip(this.label, {super.key});
  @override
  Widget build(BuildContext context) => Chip(label: Text(label), backgroundColor: auraPanel, side: BorderSide(color: auraViolet.withValues(alpha: .25)));
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});
  @override
  Widget build(BuildContext context) => const PlaceholderPage(symbol: '⟡', title: 'Discover Souls', subtitle: 'Find creativity and moods that resonate with yours.', note: 'Sample discovery screen · no real profiles yet');
}
class BondsPage extends StatelessWidget {
  const BondsPage({super.key});
  @override
  Widget build(BuildContext context) => const PlaceholderPage(symbol: '✦', title: 'Bond Garden', subtitle: 'Connections grow through moments created together.', note: 'Streaks and mutual exchanges are not connected to a server yet');
}

class InboxPage extends StatefulWidget {
  const InboxPage({super.key});
  @override
  State<InboxPage> createState() => _InboxPageState();
}

class _InboxPageState extends State<InboxPage> {
  final List<_DemoThread> threads = [
    _DemoThread(name: 'Zainab', symbol: '☾', mood: 'Midnight Echo', preview: 'That poem feels like rain on a quiet window.', time: '8:42 PM', unread: true),
    _DemoThread(name: 'Ayan', symbol: '✧', mood: 'Rainy Mood', preview: 'Shared a little moment with you.', time: 'Yesterday'),
    _DemoThread(name: 'Noor', symbol: '✦', mood: 'Sunset Glow', preview: 'Your sunset palette is beautiful.', time: 'Yesterday'),
  ];

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(20),
    children: [
      const Text('MOOD INBOX ☾', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, letterSpacing: 1.7)),
      const SizedBox(height: 6),
      const Text('Conversations that meet you where you are.', style: TextStyle(color: Colors.white60)),
      const SizedBox(height: 18),
      Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: auraViolet.withValues(alpha: .22))), child: const Row(children: [Icon(Icons.lock_outline, color: auraPink), SizedBox(width: 10), Expanded(child: Text('Privacy first. Only chat with people you choose to connect with.', style: TextStyle(fontSize: 12, color: Colors.white70, height: 1.4)))])),
      const SizedBox(height: 20),
      for (final thread in threads) ...[
        InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () async {
            final result = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => DemoChatScreen(thread: thread)));
            if (result != null && mounted) setState(() => thread.preview = result);
          },
          child: Container(
            margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(18), border: Border.all(color: thread.unread ? auraViolet.withValues(alpha: .55) : auraViolet.withValues(alpha: .16))),
            child: Row(children: [
              Container(width: 48, height: 48, decoration: BoxDecoration(shape: BoxShape.circle, color: auraViolet.withValues(alpha: .16), border: Border.all(color: auraViolet.withValues(alpha: .35))), child: Center(child: Text(thread.symbol, style: const TextStyle(fontSize: 24, color: auraPink)))),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(thread.name, style: const TextStyle(fontWeight: FontWeight.w700))), Text(thread.time, style: const TextStyle(fontSize: 10, color: Colors.white38))]), const SizedBox(height: 4), Text(thread.mood, style: const TextStyle(color: auraPink, fontSize: 11)), const SizedBox(height: 4), Text(thread.preview, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: thread.unread ? Colors.white : Colors.white54, fontSize: 12))])),
              if (thread.unread) ...[const SizedBox(width: 8), Container(width: 7, height: 7, decoration: const BoxDecoration(color: auraPink, shape: BoxShape.circle))],
            ]),
          ),
        ),
      ],
      const SizedBox(height: 8),
      const Text('DEMO MODE · messages are not sent to real people or stored in the cloud.', style: TextStyle(fontSize: 10, color: Colors.white38, letterSpacing: .5), textAlign: TextAlign.center),
    ],
  );
}

class _DemoThread {
  final String name, symbol, mood, time;
  String preview;
  bool unread;
  _DemoThread({required this.name, required this.symbol, required this.mood, required this.preview, required this.time, this.unread = false});
}

class _ChatLine {
  final String text;
  final bool mine;
  _ChatLine(this.text, this.mine);
}

class DemoChatScreen extends StatefulWidget {
  final _DemoThread thread;
  const DemoChatScreen({super.key, required this.thread});
  @override
  State<DemoChatScreen> createState() => _DemoChatScreenState();
}

class _DemoChatScreenState extends State<DemoChatScreen> {
  final composer = TextEditingController();
  final List<_ChatLine> lines = [];
  @override
  void dispose() { composer.dispose(); super.dispose(); }
  void send() {
    final text = composer.text.trim();
    if (text.isEmpty) return;
    setState(() { lines.add(_ChatLine(text, true)); composer.clear(); widget.thread.preview = text; widget.thread.unread = false; });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: auraBg, title: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(shape: BoxShape.circle, color: auraViolet.withValues(alpha: .17)), child: Center(child: Text(widget.thread.symbol, style: const TextStyle(color: auraPink)))), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.thread.name, style: const TextStyle(fontSize: 16)), Text(widget.thread.mood, style: const TextStyle(fontSize: 10, color: auraPink))])])),
    body: Column(children: [
      Container(width: double.infinity, padding: const EdgeInsets.all(10), color: auraPanel, child: const Text('Local preview · not a private, live conversation', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.white54))),
      Expanded(child: lines.isEmpty ? Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [const Text('✧', style: TextStyle(fontSize: 42, color: auraPink)), const SizedBox(height: 12), Text('A quiet moment with ${widget.thread.name}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600), textAlign: TextAlign.center), const SizedBox(height: 8), const Text('Write a thoughtful message to test the chat interface.', style: TextStyle(color: Colors.white54), textAlign: TextAlign.center)]))) : ListView(padding: const EdgeInsets.all(16), children: [for (final line in lines) Align(alignment: line.mine ? Alignment.centerRight : Alignment.centerLeft, child: Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), constraints: const BoxConstraints(maxWidth: 290), decoration: BoxDecoration(color: line.mine ? const Color(0xFF42265D) : auraPanel, borderRadius: BorderRadius.circular(17)), child: Text(line.text)))])),
      SafeArea(top: false, child: Padding(padding: const EdgeInsets.fromLTRB(12, 8, 12, 12), child: Row(children: [Expanded(child: TextField(controller: composer, minLines: 1, maxLines: 4, textInputAction: TextInputAction.send, onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'Share a feeling…', contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12)))), const SizedBox(width: 8), IconButton.filled(onPressed: send, icon: const Icon(Icons.arrow_upward), style: IconButton.styleFrom(backgroundColor: auraViolet, foregroundColor: auraBg))]))),
    ]),
  );
}

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final displayName = TextEditingController(text: 'Aura Creator');
  final bio = TextEditingController(text: 'Collecting little moments of meaning. ✧');
  bool editing = false;

  @override
  void dispose() {
    displayName.dispose();
    bio.dispose();
    super.dispose();
  }

  String get previewId {
    // UI-only preview: derives a daily label, not a secure or globally unique ID.
    // Production rotation must be generated and stored by a trusted backend.
    final now = DateTime.now().toUtc();
    final day = now.year * 1000 + now.difference(DateTime.utc(now.year)).inDays;
    final uid = FirebaseAuth.instance.currentUser?.uid ?? 'aura-demo-account';
    var hash = 17;
    for (final unit in '$uid:$day'.codeUnits) {
      hash = (hash * 31 + unit) & 0x7fffffff;
    }
    final n = hash % 1000000;
    final digits = n.toString().padLeft(6, '0');
    return 'AU-${digits.substring(0, 3)}-${digits.substring(3)}';
  }

  String get nextRotationLabel {
    final now = DateTime.now().toUtc();
    final next = DateTime.utc(now.year, now.month, now.day).add(const Duration(days: 1));
    final remaining = next.difference(now);
    return 'Demo ID refreshes at the next UTC day boundary · ${remaining.inHours}h ${remaining.inMinutes % 60}m left';
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('MY AURA ◈', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, letterSpacing: 2)),
        const SizedBox(height: 6),
        const Text('Your identity, your moments, your atmosphere.', style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(colors: [Color(0xFF38204F), Color(0xFF171020)]),
            border: Border.all(color: auraViolet.withValues(alpha: .35)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 58, height: 58, decoration: BoxDecoration(shape: BoxShape.circle, color: auraViolet.withValues(alpha: .17), border: Border.all(color: auraViolet.withValues(alpha: .6))), child: const Center(child: Text('✧', style: TextStyle(fontSize: 32, color: auraPink)))),
              const SizedBox(width: 14),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(displayName.text, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w700)),
                Text(user?.email ?? 'Local demo profile', style: const TextStyle(fontSize: 12, color: Colors.white54)),
              ])),
              IconButton(tooltip: editing ? 'Cancel editing' : 'Edit profile', onPressed: () => setState(() => editing = !editing), icon: Icon(editing ? Icons.close : Icons.edit_outlined, color: auraPink)),
            ]),
            const SizedBox(height: 16),
            if (editing) ...[
              TextField(controller: displayName, decoration: const InputDecoration(labelText: 'Display name'), onChanged: (_) => setState(() {})),
              const SizedBox(height: 12),
              TextField(controller: bio, maxLines: 3, decoration: const InputDecoration(labelText: 'Your bio'), onChanged: (_) => setState(() {})),
              const SizedBox(height: 10),
              FilledButton(onPressed: () => setState(() => editing = false), child: const Text('Save preview')),
            ] else
              Text(bio.text, style: const TextStyle(color: Colors.white70, height: 1.5)),
          ]),
        ),
        const SizedBox(height: 18),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(20), border: Border.all(color: auraViolet.withValues(alpha: .3))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.fingerprint, color: auraPink), SizedBox(width: 8), Text('YOUR PUBLIC AURA ID', style: TextStyle(letterSpacing: 1.2, fontSize: 11, color: auraPink, fontWeight: FontWeight.w600))]),
            const SizedBox(height: 10),
            Text(previewId, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold, letterSpacing: 2)),
            const SizedBox(height: 6),
            Text(nextRotationLabel, style: const TextStyle(fontSize: 11, color: Colors.white54)),
            const SizedBox(height: 14),
            const Text('Preview only: this label is derived locally and may not match across devices. It is not a secure identity token.', style: TextStyle(fontSize: 11, color: Colors.white45, height: 1.5)),
          ]),
        ),
        const SizedBox(height: 18),
        const Text('YOUR AURA', style: TextStyle(fontSize: 12, letterSpacing: 1.5, color: auraPink)),
        const SizedBox(height: 10),
        const Row(children: [Expanded(child: _ProfileStat(value: '✧', label: 'Moments')), SizedBox(width: 10), Expanded(child: _ProfileStat(value: '✦', label: 'Bonds')), SizedBox(width: 10), Expanded(child: _ProfileStat(value: '❋', label: 'Creations'))]),
        const SizedBox(height: 18),
        Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(16)), child: const Text('Backend status: profile edits are in-memory demo changes. A production profile needs a database with user-owned access rules, and public ID rotation needs server-side scheduling.', style: TextStyle(color: Colors.white54, fontSize: 12, height: 1.5))),
        if (user != null) ...[
          const SizedBox(height: 14),
          OutlinedButton.icon(onPressed: () async { await FirebaseAuth.instance.signOut(); if (context.mounted) Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const WelcomeScreen()), (route) => false); }, icon: const Icon(Icons.logout), label: const Text('Sign out')),
        ],
      ],
    );
  }
}

class _ProfileStat extends StatelessWidget {
  final String value;
  final String label;
  const _ProfileStat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8), decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(16), border: Border.all(color: auraViolet.withValues(alpha: .2))), child: Column(children: [Text(value, style: const TextStyle(fontSize: 24, color: auraPink)), const SizedBox(height: 6), Text(label, style: const TextStyle(fontSize: 11, color: Colors.white60))]));
}

class PlaceholderPage extends StatelessWidget {
  final String symbol, title, subtitle, note;
  const PlaceholderPage({super.key, required this.symbol, required this.title, required this.subtitle, required this.note});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Text(symbol, style: const TextStyle(fontSize: 54, color: auraPink)), const SizedBox(height: 14), Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold), textAlign: TextAlign.center), const SizedBox(height: 10), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, height: 1.5)), const SizedBox(height: 24), Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: auraPanel, borderRadius: BorderRadius.circular(14)), child: Text(note, style: const TextStyle(fontSize: 12, color: Colors.white45), textAlign: TextAlign.center))])));
}
