# AURA v0.7 — Real-time chat integration scaffold

## Added
- `lib/services/aura_chat_service.dart`: Firestore service methods for conversation requests, accept/decline, live conversation/message streams, text sends, block-list entries, and reports.
- `firestore.rules`: initial membership checks, consent-before-messaging, message size/type checks, immutable messages, private block-list reads, and report submission restrictions.

## Important status
This is source-code scaffolding, not a deployed or verified messaging service. The existing Flutter Inbox UI is still a local demo and is not yet wired to this service. Firebase must be configured and these rules must be deployed and tested in the Firebase Emulator before real users use it. I could not compile the Flutter project in this environment.

## Required before production
1. Connect Inbox and chat screens to `AuraChatService` and show pending requests separately from accepted chats.
2. Deploy and test Firestore rules with the Emulator Suite, including unauthorized access and malformed writes.
3. Enforce block checks on conversation creation and message sending. Current rules store a block list but do not yet enforce blocks across conversations.
4. Add rate limits / abuse prevention using a trusted backend, moderation workflow, and report review process.
5. Add pagination, unread state, push notifications, and data-retention/deletion controls.
6. Consider App Check and server-side validation. Do not claim end-to-end encryption; this scaffold does not provide it.

## Data model
- `conversations/{conversationId}`: two member UIDs, initiator UID, pending/accepted/declined status, created/updated timestamps.
- `conversations/{conversationId}/messages/{messageId}`: sender UID, text, server timestamp, type `text`.
- `users/{uid}/blockedUsers/{targetUid}`: private block-list record.
- `reports/{reportId}`: private user-submitted report, unreadable to clients.

## Setup
1. Configure Firebase for Android and enable Firebase Auth + Cloud Firestore.
2. Deploy `firestore.rules` with `firebase deploy --only firestore:rules` after reviewing the project ID.
3. Test all rules with Firebase Emulator Suite before connecting the service to the UI.
