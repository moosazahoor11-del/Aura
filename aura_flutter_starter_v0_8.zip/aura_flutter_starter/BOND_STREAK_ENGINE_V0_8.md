# AURA v0.8 — Bond Streak Engine (starter)

## Behavior
- A bond is a conversation between exactly two accepted members.
- A daily bond exchange counts only after both members send at least one message with `type: "aura"` during the same UTC calendar day.
- The Cloud Function updates `bondStreakCount`, `lastBondDay`, and `lastBondExchangeAt` on the parent conversation.
- Only one count is recorded per conversation per UTC day.
- The first qualifying day starts at 1; a consecutive UTC day increments the streak; a gap starts a new streak at 1.

## Setup
1. Install Node.js 20 and Firebase CLI.
2. Run `cd functions && npm install && npm run build`.
3. Deploy Firestore rules and Cloud Functions to a configured Firebase project.
4. Create any composite index requested by Firestore.
5. Test with the Firebase Emulator Suite using two test accounts.

## Limitations
- Starter code only; not compiled, deployed, or security-tested here.
- Flutter chat still uses local demo data and does not send `type: "aura"` messages yet.
- Uses UTC calendar days, not a rolling 24-hour window.
- Test concurrent sends, delayed triggers, abuse limits, and all edge cases before production.
