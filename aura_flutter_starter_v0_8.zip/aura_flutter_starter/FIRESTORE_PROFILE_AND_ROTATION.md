# AURA milestone: Firestore profile + server-controlled Aura ID rotation

## Added to this starter
- `cloud_firestore` dependency in `pubspec.yaml`.
- `firestore.rules` protecting private `/users/{uid}` documents and preventing clients from writing public ID lookup records.
- `functions/src/index.ts`: scheduled Cloud Function that rotates expired aliases using Admin SDK and keeps the Firebase Auth UID as the permanent account key.
- `firebase.json` and a minimal TypeScript Functions package scaffold.

## Data model
- `/users/{firebaseAuthUid}`: private profile fields plus `publicAuraId`, `auraIdCreatedAt`, and `auraIdExpiresAt`.
- `/publicAuraIds/{publicAlias}`: alias-to-UID mapping only; do not add email, phone, or other personal information.

## Setup before deployment
1. Run `flutter pub get` from the Flutter project directory.
2. Configure Firebase Android app and `google-services.json`; ensure Firebase initialization is set up for your project.
3. Install Firebase CLI and sign in; run `firebase use --add` to select your own project.
4. From `functions/`, run `npm install` and `npm run build`.
5. Deploy Firestore rules and Cloud Functions with `firebase deploy --only firestore:rules,functions`. Scheduled functions may require the Blaze billing plan and a billing-enabled Google Cloud project.
6. Build a trusted profile-create callable function before production. It must create the user document, assign the first unique alias, and set the initial expiry. The Flutter client must not write the protected alias fields.
7. Connect the Flutter profile screen to Firestore through a service and test rules in the Firebase Emulator Suite. The current UI is not yet wired to this data model.

## Important behavior and limitations
- Rotation runs hourly, so the ID changes after expiry is detected; it is not guaranteed to change at the exact second 24 hours elapse.
- The sample scheduled function rotates existing expired profiles only. It does not create profiles or assign the first alias. Add that trusted onboarding function before deploying.
- Alias rotation can temporarily invalidate a previously shared public alias. Decide whether old aliases should expire immediately or have a short redirect/grace period.
- Do not use public Aura IDs for login, authorization, or access control. Use Firebase Auth UID on the trusted backend.
- Rules and function code are starter scaffolding and have not been deployed, compiled, or security-audited in this environment. Test in a separate Firebase development project first.
